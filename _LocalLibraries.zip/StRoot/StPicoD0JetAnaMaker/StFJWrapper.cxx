// $Id$
// StFJWrapper.cxx
//
// Wrapper for FastJet
//
// the header was adapted from:
// Author: C.Loizides (adapted from M.Ploskon)

#define StFJWrapper_CXX
#include "StFJWrapper.h"
